﻿/** @namespaces */
var CG = CG || {};
CG.Demo1 = CG.Demo1 || {};

CG.Demo1.Views = {
    None: 0,
    Catalog: 1,
    Departments: 2,
    Assets: 3,
    SubAssets: 4
};

CG.Demo1.Toggles = {
    Toggle2D: 1,
    Toggle3D: 2,
    ToggleSchedule: 3
}


CG.Demo1.StartApp = function () {

    var DEFAULT_CAMERA_X = 0;
    var DEFAULT_CAMERA_Y = 0;
    var DEFAULT_CAMERA_Z = 2100;

    var _active3dObject = null;
    var _navBackTo = CG.Demo1.Views.none;
    var camera;
    var tileControls;
    var renderer;
    var scene;

    var _tileObjects = {
        studio: '',
        logo: '',
        budgetUri: '',
        movieObjects: []
    };

    var _tileVectors = {};

    var _optionsForMovieVectors = {
        offsetX: 15,
        offsetY: 15,
        offsetZ: 600,
        rise3d: 250,

        initial3dCameraX: 0,
        initial3dCameraY: -321,
        initial3dCameraZ: 1971,
        initial2dCameraX: 0,
        initial2dCameraY: 400,
        initial2dCameraZ: 2300,
        is3D: true
    };

    var _optionsForDepartmentVectors = {
        offsetX: 15,
        offsetY: 15,
        offsetZ: 500,
        rise3d: 250,

        initial3dCameraX: 0,
        initial3dCameraY: -321,
        initial3dCameraZ: 1971,
        initial2dCameraX: 0,
        initial2dCameraY: 40,
        initial2dCameraZ: 2300,
        is3D: true

    };

    var _optionsForAssetVectors = {
        offsetX: 15,
        offsetY: 15,
        offsetZ: 550,
        rise3d: 225,

        initial3dCameraX: 0,
        initial3dCameraY: -196,
        initial3dCameraZ: 2278,
        initial2dCameraX: 0,
        initial2dCameraY: 40,
        initial2dCameraZ: 3300,        
        is3D: true
    };

    var _transformOptions;
    var _currentVectorKey = null;
    var _currentTileObjects = null;
    var _currentView = CG.Demo1.Views.Catalog;
    var _currentToggle = CG.Demo1.Toggles.Toggle3D;

    var _lastMovieTile;
    var _lastDepartmentTile;
    var _lastAssetTile;
    var _studioData;
    var _itemsToPreload = [];
    var _timeline;
    var _wasLastTileView3D = true;
    var _lastTileView;

    // initialize hammer touch event manager
    var _hammer = $(document).hammer({
        swipe_velocity: 0.1
    });

    //
    // jQuery cache variables
    //

    $viewport = $('#viewport');
    $backNav = $('#backNav');
    $details = $('#details-container-inner');
    $timelineContainer = $('#timeline-container');


    //////////////////////////////////
    //////////////////////////////////
    /////  START OF FUNCTIONS  ///////
    //////////////////////////////////
    //////////////////////////////////


    function initialize() {

        if (isIDevice() === true) {
            $('#item-viewer-content').css({
                'overflow': 'scroll',
                '-webkit-overflow-scrolling': 'touch'
            });
        } else {
            $('#item-viewer-content').css('overflow', 'hidden');
        }

        // initialize scene
        scene = new THREE.Scene();

        //
        // intialize camera
        //
        camera = new THREE.PerspectiveCamera(35, window.innerWidth / window.innerHeight, -5000, 5000);
        camera.position.x = 0;
        camera.position.y = 0;
        camera.position.z = 0;
        

        //
        // initialize the CSS3 renderer
        //
        renderer = new THREE.CSS3DRenderer();
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.domElement.style.position = 'absolute';
        $viewport.append(renderer.domElement);

        // initialize all objects required for 3D rendering
        initializeTilesAndVectors();

        // initialize controls, defaulting to catalog controls
        setTransformOptions('catalog', (_currentToggle == CG.Demo1.Toggles.Toggle3D));
        var options = getTransformOptions();
        tileControls = new CG.TileControls(options, camera, render, $('#viewport'), 1000, _hammer);

        // initialize event handlers
        initializeEventHandlers();

        $('*').cineGlassPreLoader({
            barColor: 'rgba(0,0,0,0.75)',
            percentageColor: 'rgba(255,255,255,0.75)',
            backgroundColor: 'rbga(0,0,0,0.25)',
            percentage: true,
            barHeight: 30,
            completeAnimation: 'grow',
            studioData: _studioData,
            getAssetIconUrlFunction: getAssetIconUrl,
            onComplete: function () {

                //
                // kick off the 3D movies by default
                //     
                showMovieTiles();
                
                $('#product-logo').show();
                $('#details-container').show();
                $('#toggle-menu').show();
                $('#release-notes').show();

                renderDetailsContext(_currentView);

            }
        });       
              
    }

    function initializeTilesAndVectors() {

        var studioData = _studioData = CG.Demo1.DemoData();

        //
        // sort movies by release dates
        //
        studioData.catalog.sort(function (movie1, movie2) {
            if (movie1.releaseDate < movie2.releaseDate) {
                return -1;
            } else if (movie1.releaseDate > movie2.releaseDate) {
                return 1;
            } else {
                return 0;
            }
        });

        //
        // cache catalog studio info
        //
        _tileObjects.studio = studioData.name;
        _tileObjects.budgetUri = studioData.budgetUri;
        _tileObjects.logo = studioData.logo;       

        var catalog = studioData.catalog;
        var movieCount = catalog.length;

        //
        // initialize movie tiles
        //
        for (var index = 0; index < movieCount; index++) {

            var movieData = catalog[index];

            var movieName = movieData.name;

            //
            // create a tile for the movie
            //
            var tile = document.createElement('div');
            tile.className = 'movie-tile';
            tile.title = movieName;
            tile.movieData = movieData;

            //
            // create phase swatch element
            //
            var swatch = document.createElement('div');
            swatch.className = 'phase-swatch ' + movieData.currentPhase.toLowerCase();
            swatch.textContent = movieData.currentPhase;
            tile.appendChild(swatch);

            //
            // create release date element
            //
            var releaseDate = document.createElement('div');
            releaseDate.className = 'movie-tile release-date';
            releaseDate.textContent = formatDate(movieData.releaseDate);
            tile.appendChild(releaseDate);

            //
            // create one sheet element
            //
            var oneSheet = document.createElement('div');
            oneSheet.className = 'movie-tile one-sheet';
            oneSheet.style.backgroundImage = "url('" + movieData.oneSheet + "')";
            tile.appendChild(oneSheet);

            //
            // create a CSS3D object for this movie tile
            // and initialize with a random vector
            //
            var css3dObject = new THREE.CSS3DObject(tile);
            css3dObject.position.x = 0;
            css3dObject.position.y = 0;
            css3dObject.position.z = -10000;
            css3dObject.departmentObjects = [];
            scene.add(css3dObject);

            // initialize phase department tiles (this will initialize all downstream tiles as well)
            initializeDepartmentTiles(movieName, css3dObject.departmentObjects, movieData.phases);

            // cache CSS3D object on movie tile
            tile.parentObject = css3dObject;

            // cache CSS3D object on master movie array
            _tileObjects.movieObjects.push(css3dObject);
            
        }

        // initialize movie vectors
        var vectorCache = _tileVectors['catalog'] = { twoD: [], threeD: [] };
        var movieDims = getDimsFromCss('movie-tile');
        initializeVectors(movieCount, vectorCache, _optionsForMovieVectors, movieDims);

    }

    function initializeDepartmentTiles(movieName, departmentObjects, phases) {

        if (phases != null) {

            // Development Phase
            initializePhaseDepartmentTiles(departmentObjects, phases.development);

            // Pre-Production Phase
            initializePhaseDepartmentTiles(departmentObjects, phases.preProduction);

            // Production Phase
            initializePhaseDepartmentTiles(departmentObjects, phases.production);

            // Post-Production Phase
            initializePhaseDepartmentTiles(departmentObjects, phases.postProduction);

            // Distribution Phase
            initializePhaseDepartmentTiles(departmentObjects, phases.distribution);

            //
            // initialize department vectors
            //
            var vectorLength = (phases.development.departments.length +
                                phases.preProduction.departments.length +
                                phases.production.departments.length +
                                phases.postProduction.departments.length +
                                phases.distribution.departments.length);            
            var vectorCache = _tileVectors[movieName] = { twoD: [], threeD: [] };
            var deptDims = getDimsFromCss('department-tile');
            initializeVectors(vectorLength, vectorCache, _optionsForDepartmentVectors, deptDims);

        }

    }

    function initializePhaseDepartmentTiles(departmentObjects, phase) {

        var depts = phase.departments;
        var length = depts.length;

        for (var index = 0; index < length; index++) {

            var dept = depts[index];

            initializePhaseDepartmentTile(
                departmentObjects,
                phase,
                dept);
        }    

    }

    function initializePhaseDepartmentTile(departmentObjects, phase, dept) {

        //
        // create a tile for the department
        //
        var tile = document.createElement('div');
        tile.className = 'department-tile';
        tile.title = dept.name;
        tile.assets = dept.assets;
        tile.departmentName = dept.name;
        tile.start = dept.start;
        tile.end = dept.end;
        tile.phaseName = phase.name;

        //
        // create phase swatch element
        //
        var swatch = document.createElement('div');
        swatch.className = 'phase-swatch ' + phase.name.toLowerCase();
        swatch.textContent = phase.name;
        tile.appendChild(swatch);

        //
        // create department name element
        //
        var departmentName = document.createElement('div');
        departmentName.className = 'department-tile name';
        departmentName.textContent = dept.name;
        tile.appendChild(departmentName);

        //
        // create logo element
        //
        var logo = document.createElement('div');
        logo.className = 'department-tile logo';
        logo.style.backgroundImage = "url('" + (typeof dept.iconUri == 'undefined' ? phase.iconUri : dept.iconUri) + "')";

        tile.appendChild(logo);

        //
        // create a CSS3D object for this movie tile
        // and initialize with a random Z vector
        //
        var css3dObject = new THREE.CSS3DObject(tile);
        css3dObject.position.x = 0;
        css3dObject.position.y = 0;
        css3dObject.position.z = -10000;
        css3dObject.assetObjects = [];
        scene.add(css3dObject);

        // initialize tiles for this phase department's assets
        initializeAssetTiles(css3dObject.assetObjects, phase, dept);

        // add department object to array
        departmentObjects.push(css3dObject);

        // cache department element on department tile
        tile.parentObject = css3dObject;

        $(tile).hide();

    }

    function initializeAssetTiles(assetObjects, phase, dept) {

        var deptName = dept.name;
        var assets = dept.assets;
        var assetsLength = assets.length;
        var categories = {};

        var assetVectorCount = 0;

        for (var index = 0; index < assetsLength; index++) {

            var asset = assets[index];

            if (asset.category.length > 0) {

                if (!categories.hasOwnProperty(asset.category)) {

                    //
                    // create a tile for the asset category
                    //
                    var categoryTile = document.createElement('div');
                    categoryTile.className = 'asset-tile category';
                    categoryTile.phaseName = phase.name;
                    categoryTile.departmentName = dept.name;
                    categoryTile.categoryName = asset.category;
                    categoryTile.title = asset.category;

                    //
                    // create phase swatch element
                    //
                    var swatch = document.createElement('div');
                    swatch.className = 'phase-swatch ' + phase.name.toLowerCase();
                    swatch.textContent = phase.name;
                    categoryTile.appendChild(swatch);

                    //
                    // create asset name element
                    //
                    var assetName = document.createElement('div');
                    assetName.className = 'asset-tile name';
                    assetName.textContent = asset.category;
                    categoryTile.appendChild(assetName);

                    var logo = document.createElement('div');
                    logo.className = 'asset-tile logo';
                    logo.style.backgroundImage = getAssetIconUrl(null);
                    categoryTile.appendChild(logo);

                    //
                    // create a CSS3D object for this movie tile
                    // and initialize with a random vector
                    //
                    var css3dObject = new THREE.CSS3DObject(categoryTile);
                    css3dObject.position.x = 0;
                    css3dObject.position.y = 0;
                    css3dObject.position.z = -10000;
                    css3dObject.subAssetObjects = [];
                    scene.add(css3dObject);

                    // add category object to array
                    assetObjects.push(css3dObject);

                    // cache category object on category tile
                    categoryTile.parentObject = css3dObject;

                    // temporarily cache categoryTile object
                    categories[asset.category] = css3dObject;

                    // one asset vector needs to be counted
                    // for each unique category
                    assetVectorCount++;

                    $(categoryTile).hide();
                }

                //
                // create a tile for the sub-asset
                //
                var tile = document.createElement('div');
                tile.className = 'asset-tile';
                tile.title = asset.name;
                tile.asset = asset;

                //
                // create phase swatch element
                //
                var swatch = document.createElement('div');
                swatch.className = 'phase-swatch ' + phase.name.toLowerCase();
                swatch.textContent = phase.name;
                tile.appendChild(swatch);

                //
                // create asset name element
                //
                var assetName = document.createElement('div');
                assetName.className = 'asset-tile name';
                assetName.textContent = asset.name;
                tile.appendChild(assetName);

                var logo = document.createElement('div');
                logo.className = 'asset-tile logo';
                logo.style.backgroundImage = getAssetIconUrl(asset);

                tile.appendChild(logo);

                //
                // create a CSS3D object for this movie tile
                // and initialize with a random vector
                //
                var css3dObject = new THREE.CSS3DObject(tile);
                css3dObject.position.x = 0;
                css3dObject.position.y = 0;
                css3dObject.position.z = -10000;
                scene.add(css3dObject);

                // add sub-asset object to array
                categories[asset.category].subAssetObjects.push(css3dObject);

                // cache asset object on asset tile
                tile.parentObject = css3dObject;

                $(tile).hide();

            } else {

                //
                // create a tile for the asset
                //
                var tile = document.createElement('div');
                tile.className = 'asset-tile';
                tile.title = asset.name;
                tile.asset = asset;

                //
                // create phase swatch element
                //
                var swatch = document.createElement('div');
                swatch.className = 'phase-swatch ' + phase.name.toLowerCase();
                swatch.textContent = phase.name;
                tile.appendChild(swatch);

                //
                // create asset name element
                //
                var assetName = document.createElement('div');
                assetName.className = 'asset-tile name';
                assetName.textContent = asset.name;
                tile.appendChild(assetName);

                var logo = document.createElement('div');
                logo.className = 'asset-tile logo';
                logo.style.backgroundImage = getAssetIconUrl(asset);
                tile.appendChild(logo);

                //
                // create a CSS3D object for this movie tile
                // and initialize with a random vector
                //
                var css3dObject = new THREE.CSS3DObject(tile);
                css3dObject.position.x = 0;
                css3dObject.position.y = 0;
                css3dObject.position.z = -10000;
                scene.add(css3dObject);

                // add asset object to array
                assetObjects.push(css3dObject);

                // cache asset object on asset tile
                tile.parentObject = css3dObject;
                tile.phaseName = phase.name;
                tile.departmentName = deptName;

                assetVectorCount++;

                $(tile).hide();

            }

            // initialize asset vectors
            var assetVectorCache = _tileVectors[phase.name + '|' + deptName] = { twoD: [], threeD: [] };
            var assetDims = getDimsFromCss('asset-tile');
            initializeVectors(assetVectorCount, assetVectorCache, _optionsForAssetVectors, assetDims);

            //
            // initialize sub-asset vectors for ALL categories
            //
            $.each(categories, function (category, categoryObject) {
                
                var subAssetCount = categoryObject.subAssetObjects.length;

                // initialize sub-asset vectors
                var subAssetVectorCache = _tileVectors[phase.name + '|' + deptName + '|' + category] = { twoD: [], threeD: [] };
                initializeVectors(subAssetCount, subAssetVectorCache, _optionsForAssetVectors, assetDims);

            });

        }
    }
    
    function initializeVectors(vectorCount, vectorCache, vectorOptions, objectDims) {

        var vectorsPerRow = calculateVectorsPerRow(vectorCount);
        var tileOffsetWidth = (objectDims.width + vectorOptions.offsetX);
        var rowCount = Math.ceil(vectorCount / vectorsPerRow);
        var finalRowCount = vectorCount % vectorsPerRow;
        var vectorCounter = 0;

        var firstLeft;

        if (vectorCount === 1) {

            firstLeft = 0;

        } else if (vectorCount === 2) {

            firstLeft = tileOffsetWidth / 2 * -1;

        } else if (vectorsPerRow % 2 === 0) {

            firstLeft = (Math.floor(vectorsPerRow / 2) * tileOffsetWidth - (tileOffsetWidth / 2)) * -1;

        } else {

            firstLeft = Math.floor(vectorsPerRow / 2) * tileOffsetWidth * -1;

        }

        for (var rowIndex = 0; rowIndex < rowCount; rowIndex++) {

            var y3d = ((rowIndex % rowCount) * (vectorOptions.offsetY + vectorOptions.rise3d)) - ((vectorOptions.offsetY + vectorOptions.rise3d) * 2);
            var z3d = (vectorOptions.offsetZ * rowIndex) * -1;
            var y2d = ((objectDims.height + vectorOptions.offsetY) * Math.floor(rowCount / 2)) - ((rowIndex % rowCount) * (objectDims.height + vectorOptions.offsetY));

            var x = firstLeft;

            for (var objectIndex = 0; objectIndex < vectorsPerRow; objectIndex++) {

                if (vectorCounter == vectorCount) {
                    break;
                }

                //
                // 3D vectors
                //
                var vector3D = new THREE.Object3D();
                vector3D.position.x = x;
                vector3D.position.y = y3d;
                vector3D.position.z = z3d;
                vectorCache.threeD.push(vector3D);


                //
                // 2D vectors
                //
                var vector2D = new THREE.Object3D();
                vector2D.position.x = x;
                vector2D.position.y = y2d;
                vector2D.position.z = 0;
                vectorCache.twoD.push(vector2D);

                x += tileOffsetWidth;

                vectorCounter++;
            }
        }
    }
    
    function initializeEventHandlers() {
        
        $(document).on('selectstart', function (event) {
            //
            // cancel selection/highlighting
            //
            return false;
        });

        $(window).on('resize orientationchange', function (event) {
            onWindowResize();            
        });       

        //
        // wire-up tap event handler for movie tile
        //
        _hammer.on('tap', '.movie-tile', function (event) {

            event.gesture.preventDefault();

            if (tileControls.disabled === true) {
                return;
            }

            var tile;

            if (event.gesture.target.parentObject) {
                tile = event.gesture.target;
            } else {
                tile = event.gesture.target.parentElement;
            }

            showDepartments(tile);

            return false;

        });

        //
        // wire-up tap event handler for department tile
        //
        _hammer.on('tap', '.department-tile', function (event) {

            event.gesture.preventDefault();

            if (tileControls.disabled === true) {
                return;
            }

            var tile;

            if (event.gesture.target.parentObject) {
                tile = event.gesture.target;
            } else {
                tile = event.gesture.target.parentElement;
            }

            showAssets(tile);

            return false;

        });

        //
        // wire-up tap event handler for category tile
        //
        _hammer.on('tap', '.asset-tile.category', function (event) {

            event.gesture.preventDefault();

            if (tileControls.disabled === true) {
                return;
            }

            var tile;

            if (event.gesture.target.parentObject) {
                tile = event.gesture.target;
            } else {
                tile = event.gesture.target.parentElement;
            }

            showSubAssets(tile);

        });

        //
        // wire-up tap event handler for department tile
        //
        _hammer.on('tap', '.asset-tile', function (event) {

            if (tileControls.disabled === true) {
                return;
            }

            var tile;

            if (event.gesture.target.parentObject) {
                tile = event.gesture.target;
            } else {
                tile = event.gesture.target.parentElement;
            }

            var asset = tile.asset;

            if (typeof asset != 'undefined') {
                showItemViewer(asset.name, asset.assetUri, asset.type);
                event.gesture.preventDefault();
            }

        });

        _hammer.on('tap', '#tiles3d', function (event) {

            event.gesture.preventDefault();

            if (tileControls.disabled === false) {
                toggleView(CG.Demo1.Toggles.Toggle3D, 800);
            }

        });

        _hammer.on('tap', '#tiles2d', function (event) {

            event.gesture.preventDefault();

            if (tileControls.disabled === false) {
                toggleView(CG.Demo1.Toggles.Toggle2D, 800);
            }

        });

        _hammer.on('tap', '#schedule2d', function (event) {

            event.gesture.preventDefault();

            if (tileControls.disabled === false) {
                toggleView(CG.Demo1.Toggles.ToggleSchedule, 800);
            }

        });

        _hammer.on('tap', '#item-viewer-close', function (event) {

            event.gesture.preventDefault();

            // clear the viewer's contents
            $('#itemViewer').attr({
                src: 'about:blank'
            });

            $('#item-viewer-mask, #item-viewer-dialog').fadeOut(300, function () {
                $('#item-viewer-mask').remove();
            });

            return false;

        });

        _hammer.on('tap', '#details-expand-collapse', function (event) {

            event.gesture.preventDefault();

            if (typeof (Storage) !== "undefined") {

                localStorage.setItem('detailsIsExpanded-' + _currentView, !$('#details-context-wrapper').is(':visible'));
            }

            renderDetailsContext(_currentView);

            return false;

        });

        _hammer.on('tap', '#backNav', function (event) {

            event.gesture.preventDefault();
            navBack();

        });

        _hammer.on('tap', '#release-notes', function (event) {
            event.gesture.preventDefault();
            showItemViewer('CineGlass Release Notes', '../release-notes.txt', 'txt');
        });

        _hammer.on('tap', '#mini-timeline-container', function (event) {
            event.gesture.preventDefault();
            toggleView(CG.Demo1.Toggles.ToggleSchedule, 800);
        });        

    }
    
    function showMovieTiles(isScheduleView) {
        
        // change page background to use studio's logo
        $viewport.css('background-image', 'url("' + _tileObjects.logo + '")');

        // hide movie countdown clock
        hideReleaseCountdown();

        $details.empty();

        var caption = document.createElement('div');
        caption.id = 'details-caption';
        caption.textContent = _studioData.name;
        $details.append(caption);

        var contextWrapper = document.createElement('div');
        contextWrapper.id = 'details-context-wrapper';
        $details.append(contextWrapper);

        var context = document.createElement('div');
        context.className = 'details-item-info';
        context.textContent = 'Pipeline Catalog';
        contextWrapper.appendChild(context);

        var budgetContainer = document.createElement('div');
        budgetContainer.id = 'budget-container';
        contextWrapper.appendChild(budgetContainer);

        var budgetIcon = document.createElement('div');        
        budgetIcon.title = 'Studio Budget';
        budgetIcon.className = 'studio-budget-icon';
        budgetContainer.appendChild(budgetIcon);


        if (_studioData.budgetUri.length > 0) {
            
            budgetIcon.itemSource = _studioData.budgetUri;
            budgetIcon.itemType = _studioData.budgetType;

        } else {

            $(budgetIcon).addClass('icon-disabled');
            budgetIcon.disabled = true;

        }

        $(budgetIcon).hammer().on('tap', function (event) {

            // show studio budget
            showItemViewer(this.title, this.itemSource, this.itemType);

        });

        var budgetLabel = document.createElement('div');
        budgetLabel.className = 'studio-budget-label';
        budgetLabel.textContent = 'Studio Budget';
        budgetContainer.appendChild(budgetLabel);

        //if (!isScheduleView) {

            // set options for rendering
            setTransformOptions('catalog', (_currentToggle == CG.Demo1.Toggles.Toggle3D));
            var options = getTransformOptions();

            // initialize controls
            tileControls.reset(options, camera, render, $('#viewport'), 1000, _hammer);

            // start transformation rendering
            transform(_tileObjects.movieObjects, 'catalog', 500);            
                       
        //}

        // set back nav button
        setBackNav(CG.Demo1.Views.None, '');

        _currentView = CG.Demo1.Views.Catalog;
        _lastTileView = CG.Demo1.Views.Catalog;

        renderDetailsContext(_currentView);
    }

    function showDepartments(movieTile, isScheduleView) {

        _lastMovieTile = movieTile;

        // change page background to one-sheet
        $viewport.css('background-image', 'url("' + getFileDirectory(movieTile.movieData.oneSheet) + '/original-size/' + getFileName(movieTile.movieData.oneSheet) + '")');

        // show countdown clock for this movie
        showReleaseCountdown(movieTile.movieData.releaseDate, movieTile.movieData.releaseCountry);

        // create expander box for movie details
        renderMovieDetails(movieTile);

        if (!isScheduleView) {

            // set options for rendering
            setTransformOptions('department', (_currentToggle == CG.Demo1.Toggles.Toggle3D));
            var options = getTransformOptions();

            // initialize the controls
            tileControls.reset(options, camera, render, $('#viewport'), 1000, _hammer);

            // start transformation rendering
            transform(movieTile.parentObject.departmentObjects, movieTile.movieData.name, 500);

            // set back nav button
            setBackNav(CG.Demo1.Views.Catalog, 'Pipeline Catalog');
            

        } else {

            // set back nav button
            setBackNav(CG.Demo1.Views.CatalogSchedule, 'Pipeline Catalog');

        }

        _currentView = CG.Demo1.Views.Departments;
        _lastTileView = CG.Demo1.Views.Departments;

        renderDetailsContext(_currentView);
    }

    function renderMovieDetails(movieTile) {

        $details.empty();

        var caption = document.createElement('div');
        caption.id = 'details-caption';
        caption.textContent = movieTile.movieData.name;
        $details.append(caption);

        var phaseCaption = document.createElement('div');
        phaseCaption.className = 'details-item-phase ' + movieTile.movieData.currentPhase.toLowerCase();
        phaseCaption.textContent = 'In ' + movieTile.movieData.currentPhase;
        $details.append(phaseCaption);

        var contextWrapper = document.createElement('div');
        contextWrapper.id = 'details-context-wrapper';
        $details.append(contextWrapper);

        //
        // build mini-timeline
        //
        var miniTimeline = buildMovieMiniTimeline(movieTile.movieData);
        if (miniTimeline != null) {
            contextWrapper.appendChild(miniTimeline);
        }

        var context = document.createElement('div');
        context.className = 'details-item-info';
        context.textContent = movieTile.movieData.genre + '  -  ' + formatDate(movieTile.movieData.releaseDate) + ' (' + movieTile.movieData.releaseCountry + ')';
        contextWrapper.appendChild(context);

        var directorsDiv = document.createElement('div');
        directorsDiv.className = 'details-item-cast';
        contextWrapper.appendChild(directorsDiv);
        var directorsLabel = document.createElement('span');
        directorsLabel.className = 'label';
        directorsLabel.textContent = 'Directors:';
        directorsDiv.appendChild(directorsLabel);
        var directorsValue = document.createElement('span');
        directorsValue.className = 'value';
        directorsValue.textContent = movieTile.movieData.topCredits.directors;
        directorsDiv.appendChild(directorsValue);

        var writersDiv = document.createElement('div');
        writersDiv.className = 'details-item-cast';
        contextWrapper.appendChild(writersDiv);
        var writersLabel = document.createElement('span');
        writersLabel.className = 'label';
        writersLabel.textContent = 'Writers:';
        writersDiv.appendChild(writersLabel);
        var writersValue = document.createElement('span');
        writersValue.className = 'value';
        writersValue.textContent = movieTile.movieData.topCredits.writers;
        writersDiv.appendChild(writersValue);

        var starsDiv = document.createElement('div');
        starsDiv.className = 'details-item-cast';
        contextWrapper.appendChild(starsDiv);
        var starsLabel = document.createElement('span');
        starsLabel.className = 'label';
        starsLabel.textContent = 'Stars:';
        starsDiv.appendChild(starsLabel);
        var starsValue = document.createElement('span');
        starsValue.className = 'value';
        starsValue.textContent = movieTile.movieData.topCredits.stars;
        starsDiv.appendChild(starsValue);

        var budgetContainer = document.createElement('div');
        budgetContainer.id = 'budget-container';
        contextWrapper.appendChild(budgetContainer);

        var movieBudgetItem = document.createElement('div');
        movieBudgetItem.className = 'budget-item';
        budgetContainer.appendChild(movieBudgetItem);

        var movieBudgetIcon = document.createElement('div');
        movieBudgetIcon.title = 'Movie Budget';
        movieBudgetIcon.className = 'icon';
        movieBudgetItem.appendChild(movieBudgetIcon);

        if (movieTile.movieData.budgetUri.length > 0) {

            movieBudgetIcon.itemSource = movieTile.movieData.budgetUri;
            movieBudgetIcon.itemType = movieTile.movieData.budgetType;

        } else {

            $(movieBudgetIcon).addClass('icon-disabled');
            movieBudgetIcon.disabled = true;

        }

        $(movieBudgetIcon).hammer().on('tap', function (event) {

            // show movie budget
            showItemViewer(this.title, this.itemSource, this.itemType);

        });

        var movieBudgetLabel = document.createElement('div');
        movieBudgetLabel.className = 'label';
        movieBudgetLabel.textContent = 'Movie Budget';
        movieBudgetItem.appendChild(movieBudgetLabel);

        var prodBudgetItem = document.createElement('div');
        prodBudgetItem.className = 'budget-item';
        budgetContainer.appendChild(prodBudgetItem);

        var prodBudgetIcon = document.createElement('div');
        prodBudgetIcon.title = 'Prod Budget';
        prodBudgetIcon.className = 'icon';
        prodBudgetItem.appendChild(prodBudgetIcon);

        if (movieTile.movieData.phases &&
            movieTile.movieData.phases.production.budgetUri.length > 0) {

            prodBudgetIcon.itemSource = movieTile.movieData.phases.production.budgetUri;
            prodBudgetIcon.itemType = movieTile.movieData.phases.production.budgetType;

        } else {

            $(prodBudgetIcon).addClass('icon-disabled');
            prodBudgetIcon.disabled = true;

        }

        $(prodBudgetIcon).hammer().on('tap', function (event) {

            // show prod budget
            showItemViewer(this.title, this.itemSource, this.itemType);

        });

        var prodBudgetLabel = document.createElement('div');
        prodBudgetLabel.className = 'label';
        prodBudgetLabel.textContent = 'Prod Budget';
        prodBudgetItem.appendChild(prodBudgetLabel);


        var postBudgetItem = document.createElement('div');
        postBudgetItem.className = 'budget-item';
        budgetContainer.appendChild(postBudgetItem);

        var postBudgetIcon = document.createElement('div');
        postBudgetIcon.title = 'Post Budget';
        postBudgetIcon.className = 'icon';
        postBudgetItem.appendChild(postBudgetIcon);

        if (movieTile.movieData.phases && movieTile.movieData.phases.postProduction.budgetUri.length > 0) {

            postBudgetIcon.itemSource = movieTile.movieData.phases.postProduction.budgetUri;
            postBudgetIcon.itemType = movieTile.movieData.phases.postProduction.budgetType;

        } else {

            $(postBudgetIcon).addClass('icon-disabled');
            postBudgetIcon.disabled = true;

        }

        $(postBudgetIcon).hammer().on('tap', function (event) {

            // show post budget
            showItemViewer(this.title, this.itemSource, this.itemType);

        });

        var postBudgetLabel = document.createElement('div');
        postBudgetLabel.className = 'label';
        postBudgetLabel.textContent = 'Post Budget';
        postBudgetItem.appendChild(postBudgetLabel);

    }

    function showAssets(departmentTile) {

        $timelineContainer.fadeOut('slow');
        $viewport.fadeIn('slow');

        _lastDepartmentTile = departmentTile;
        

        $details.empty();

        var phaseCaption = document.createElement('div');
        phaseCaption.className = 'details-item-phase ' + departmentTile.phaseName.toLowerCase();
        phaseCaption.textContent = departmentTile.phaseName;
        $details.append(phaseCaption);

        var caption = document.createElement('div');
        caption.id = 'details-caption';
        caption.textContent = departmentTile.departmentName;
        $details.append(caption);

        var contextWrapper = document.createElement('div');
        contextWrapper.id = 'details-context-wrapper';
        $details.append(contextWrapper);

        var dates = document.createElement('div');
        dates.className = 'details-item-info';
        dates.textContent = formatDate(departmentTile.start) + ' thru ' + formatDate(departmentTile.end);
        contextWrapper.appendChild(dates);
     
        // set options for rendering
        setTransformOptions('asset', (_currentToggle == CG.Demo1.Toggles.Toggle3D));
        var options = getTransformOptions();

        // initialize the controls
        tileControls.reset(options, camera, render, $('#viewport'), 1000, _hammer);

        // start transformation rendering
        transform(departmentTile.parentObject.assetObjects, departmentTile.phaseName + '|' + departmentTile.departmentName, 500);

        // set back nav button
        setBackNav(CG.Demo1.Views.Departments, 'Departments');

        _currentView = CG.Demo1.Views.Assets;
        _lastTileView = CG.Demo1.Views.Assets;

        renderDetailsContext(_currentView);

    }

    function showSubAssets(assetTile) {

        $timelineContainer.fadeOut('slow');
        $viewport.fadeIn('slow');

        _lastAssetTile = assetTile;

        // set options for rendering
        setTransformOptions('asset', (_currentToggle == CG.Demo1.Toggles.Toggle3D));
        var options = getTransformOptions();

        // initialize the controls
        tileControls.reset(options, camera, render, $('#viewport'), 1000, _hammer);

        // start transformation rendering
        transform(assetTile.parentObject.subAssetObjects, assetTile.phaseName + '|' + assetTile.departmentName + '|' + assetTile.categoryName, 500);

        // set back nav button
        setBackNav(CG.Demo1.Views.Assets, assetTile.phaseName + ' - ' + assetTile.departmentName);
    }

    function setBackNav(view, caption) {

        _navBackTo = view;

        $backNav.attr('title', caption);

        var backNav = $backNav.get(0);

        if (view == CG.Demo1.Views.None) {

            if ($backNav.css('display') !== 'none') {
                new TWEEN.FadeOut(backNav, 200);
            }
        } else {
            new TWEEN.FadeIn(backNav, 1000);
        }

    }

    function navBack() {

        if (tileControls.disabled === true) {
            return;
        }

        switch (_navBackTo) {

            case CG.Demo1.Views.Catalog:
                showMovieTiles();
                break;
            case CG.Demo1.Views.Departments:
                showDepartments(_lastMovieTile);
                break;
            case CG.Demo1.Views.Assets:
                showAssets(_lastDepartmentTile);
                break;
            case CG.Demo1.Views.SubAssets:
                showSubAssets(_lastAssetTile);
                break;
            case CG.Demo1.Views.CatalogSchedule:
                showMovieTiles(true);
                toggleView(CG.Demo1.Toggles.ToggleSchedule, 800);
                break;
        }

    }

    function getAssetIconUrl(asset) {
        if (asset === null) {
            return ("url('img/icons/folder.png')");
        } else if (asset.type.toLowerCase() === 'img') {
            return "url('" + getFileDirectory(asset.assetUri) + '/small/' + getFileName(asset.assetUri) + "')";
        } else {
            return ("url('img/icons/" + asset.type.toLowerCase() + ".png')");
        }
    }

    function getEncoding(itemType) {

        switch (itemType.toLowerCase()) {
            case 'mov': return 'video/mpeg';
            case 'doc': return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
            case 'eml': return 'message/rfc822';
            case 'pdf': return 'application/pdf';
            case 'img': return 'image/png';
            case 'xls': return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            case 'txt': return 'text/plain';
            default: return ''
        }

    }

    function getFileDirectory(filePath) {
        if (filePath.indexOf("/") == -1) { // windows
            return filePath.substring(0, filePath.lastIndexOf('\\'));
        }
        else { // unix
            return filePath.substring(0, filePath.lastIndexOf('/'));
        }
    }

    function getFileName(filePath) {
        if (filePath.indexOf("/") == -1) { // windows
            return filePath.substring(filePath.lastIndexOf('\\') + 1);
        }
        else { // unix
            return filePath.substring(filePath.lastIndexOf('/') + 1);
        }
    }    
   
    function toggleView(toggle, duration) {

        if (!_tileVectors[_currentVectorKey]) {
            return;
        }

        var previousToggle = _currentToggle;
        _currentToggle = toggle;

        if (toggle == CG.Demo1.Toggles.ToggleSchedule) {
                       
            hide2D3DView();
            showScheduleView(800);
            
        } else {

            hideScheduleView();

            if (previousToggle == CG.Demo1.Toggles.ToggleSchedule) {
                //
                // need to ensure proper tile level is set
                //

                if (_lastTileView == CG.Demo1.Views.Catalog) {
                    showMovieTiles(false);
                } else {
                    showDepartments(_lastMovieTile, false);
                }
            } else {

                tileControls.disabled = true;

                TWEEN.removeAll();

                var toVectors;

                if (toggle == CG.Demo1.Toggles.Toggle3D) {

                    _wasLastTileView3D = true;
                    tileControls.is3D = true;
                    toVectors = _tileVectors[_currentVectorKey].threeD;

                } else {

                    _wasLastTileView3D = false;
                    tileControls.is3D = false;
                    toVectors = _tileVectors[_currentVectorKey].twoD;

                }

                var maxDuration = 0;
                var initialPosition = getInitialCameraPosition((toggle == CG.Demo1.Toggles.Toggle3D));

                if (camera.position.x != initialPosition.x ||
                    camera.position.y != initialPosition.y ||
                    camera.position.z != initialPosition.z) {

                    //
                    // tween camera to it's original position
                    //

                    var cameraDuration = Math.random() * duration + duration;
                    maxDuration = Math.max(maxDuration, cameraDuration);

                    new TWEEN.Tween(camera.position)
                        .to({ x: initialPosition.x, y: initialPosition.y, z: initialPosition.z }, cameraDuration)
                        .easing(TWEEN.Easing.Exponential.Out)
                        .start();
                }

                //
                // tween all of the current tiles to
                // their other dimensions, accordingly
                //

                var vectorLength = toVectors.length;
                for (var index = 0; index < vectorLength; index++) {

                    var tileDuration = Math.random() * duration + duration;
                    maxDuration = Math.max(maxDuration, tileDuration);

                    var fromObject = _currentTileObjects[index];
                    var toVector = toVectors[index];

                    new TWEEN.Tween(fromObject.position)
                        .to({ x: toVector.position.x, y: toVector.position.y, z: toVector.position.z }, tileDuration)
                        .easing(TWEEN.Easing.Exponential.Out)
                        .start();
                }

                new TWEEN.Tween(this)
                    .to({}, maxDuration)
                    .onUpdate(render)
                    .onComplete(function () {

                        tileControls.disabled = false;

                    })
                    .start();

            }

        }

    }

    function transform(toTileObjects, toVectorKey, duration) {

        if (tileControls.disabled === true) {
            return;
        }

        tileControls.disabled = true;

        TWEEN.removeAll();

        if (_currentTileObjects != null) {

            //
            // tween the current tileObjects to a vanishing vector
            //
            var fromLength = _currentTileObjects.length;

            for (var index = 0; index < fromLength; index++) {

                var fromObject = _currentTileObjects[index];

                fromObject.position.x = 0;
                fromObject.position.y = 0;
                fromObject.position.z = -10000;

                $(fromObject.element).hide();                
                 
            }

        }

        var maxDuration = 0;
        var initialPosition = getInitialCameraPosition((_currentToggle == CG.Demo1.Toggles.Toggle3D));

        if (camera.position.x != initialPosition.x ||
            camera.position.y != initialPosition.y ||
            camera.position.z != initialPosition.z) {

            //
            // tween camera to it's original position
            //

            var cameraDuration = Math.random() * duration + duration;
            maxDuration = Math.max(maxDuration, cameraDuration);

            new TWEEN.Tween(camera.position)
                .to({ x: initialPosition.x, y: initialPosition.y, z: initialPosition.z }, cameraDuration)
                .easing(TWEEN.Easing.Exponential.Out)
                .start();
        }

        //
        // tween the TO tileObjects to their last known vectors
        //        
        var toLength = toTileObjects.length;
        for (var index = 0; index < toLength; index++) {

            var toObject = toTileObjects[index];
            var toVector;

            if ((_currentToggle == CG.Demo1.Toggles.Toggle3D)) {
                toVector = _tileVectors[toVectorKey].threeD[index];
            } else {
                toVector = _tileVectors[toVectorKey].twoD[index];
            }

            var tileDuration = Math.random() * duration + duration;
            maxDuration = Math.max(maxDuration, tileDuration);

            new TWEEN.FadeIn(toObject.element, tileDuration);

            new TWEEN.Tween(toObject.position)
                .to({ x: toVector.position.x, y: toVector.position.y, z: toVector.position.z }, tileDuration)
                .easing(TWEEN.Easing.Exponential.Out)
                .start();

        }

        new TWEEN.Tween(this)
			.to({}, maxDuration)
			.onUpdate(render)
			.onComplete(function () {

			    _currentVectorKey = toVectorKey;
			    _currentTileObjects = toTileObjects;
			    tileControls.disabled = false;

			})
            .start();

    }

    function animate() {

        requestAnimationFrame(animate);
        TWEEN.update();        

    }

    function render() {
        
        renderer.render(scene, camera);

    }

    function resetCamera() {

        var initialPosition = getInitialCameraPosition((_currentToggle == CG.Demo1.Toggles.Toggle3D));

        if (camera.position.x != initialPosition.x ||
            camera.position.y != initialPosition.y ||
            camera.position.z != initialPosition.z) {

            tileControls.disabled = true;

            $viewport.itemViewer('hide');

            new TWEEN.Tween(camera.position)
                .to({ x: initialPosition.x, y: initialPosition.y, z: initialPosition.z }, 1500)
                .easing(TWEEN.Easing.Exponential.Out)
                .onUpdate(render)
                .onComplete(function () {
                    tileControls.disabled = false;
                })
                .start();

        }

    }
    
    function disableEvent(event) {

        event.preventDefault();

    }
      
    function calculateVectorsPerRow(vectorCount) {
        if (vectorCount > 15) {
            return 5;
        } else {
            return 3;
        }
    }

    function getDimsFromCss(cssClass) {

        var $temp = $("<div class='" + cssClass + "'></div>").hide().appendTo("body");

        var width = parseInt($temp.css('width'), 10);
        var height = parseInt($temp.css('height'), 10);

        $temp.remove();

        var dims = { 'width': width, 'height': height };

        return dims;

    }

    function setTransformOptions(view, is3D) {
        switch (view.toLowerCase()) {
            case 'catalog':
                _transformOptions = _optionsForMovieVectors;
                break;
            case 'department':
                _transformOptions = _optionsForDepartmentVectors;
                break;
            case 'asset':
                _transformOptions = _optionsForAssetVectors;
                break;
        }

        _transformOptions.is3D = is3D;

    }

    function getTransformOptions() {
        return _transformOptions;
    }

    function getInitialCameraPosition(is3D) {

        var position = {};
        
        if (is3D) {
            position.x = _transformOptions.initial3dCameraX;
            position.y = _transformOptions.initial3dCameraY;
            position.z = _transformOptions.initial3dCameraZ;
        } else {
            position.x = _transformOptions.initial2dCameraX;
            position.y = _transformOptions.initial2dCameraY;
            position.z = _transformOptions.initial2dCameraZ;
        }

        return position;
    }

    function formatDate(date) {
        return (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
    }

    function onWindowResize() {

        resizeItemViewer();
        redrawTimeline();

    	camera.aspect = window.innerWidth / window.innerHeight;

    	camera.updateProjectionMatrix();

    	renderer.setSize(window.innerWidth, window.innerHeight);

    	render();
    }

    function showItemViewer(caption, itemSrc, itemType) {

        itemType = itemType.toLowerCase();

        var isIpad = isIDevice();

        var useItemViewer = (itemType == 'img' || itemType == 'mov');

        if (useItemViewer) {

            resizeItemViewer();

            $('#itemViewer').attr({
                src: itemSrc
            });

            $('#item-viewer-header').text(caption);

            $('#item-viewer-dialog').fadeIn(300);

            // Add the mask to body
            $('body').append('<div id="item-viewer-mask"></div>');
            $('#item-viewer-mask').fadeIn(300);

        } else {

            window.open(itemSrc, caption);

        }

    }

    function resizeItemViewer() {

        var MARGIN = 24;

        var $dialog = $('#item-viewer-dialog');
        var $header = $('#item-viewer-header');

        var dialogWidth = Math.round(window.innerWidth * 0.85);
        var dialogHeight = Math.round(window.innerHeight * 0.85);

        $dialog.css({
            width: dialogWidth + 'px',
            height: dialogHeight + 'px'
        });

        $('#item-viewer-content').css({
            width: dialogWidth + 'px',
            height: dialogHeight - $header.height() - (MARGIN * 2) + 'px'
        });

        // center align
        var viewerMarginTop = (dialogHeight + MARGIN) / 2;
        var viewerMarginLeft = (dialogWidth + MARGIN) / 2;

        $dialog.css({
            'margin-top': -viewerMarginTop,
            'margin-left': -viewerMarginLeft
        });

    }

    function isIDevice() {

        var isIDevice = navigator.userAgent.match(/iPad/i) != null;

        if (!isIDevice) {

            isIDevice = (
                //Detect iPhone
                (navigator.platform.indexOf("iPhone") != -1) ||
                //Detect iPod
                (navigator.platform.indexOf("iPod") != -1)
            );
        }

        return isIDevice;

    }

    function sortMovieDepartments(movieData, byStart) {
        sortDepartments(movieData.phases.development.departments, byStart);
        sortDepartments(movieData.phases.preProduction.departments, byStart);
        sortDepartments(movieData.phases.production.departments, byStart);
        sortDepartments(movieData.phases.postProduction.departments, byStart);
        sortDepartments(movieData.phases.distribution.departments, byStart);
    }

    function sortDepartments(depts, byStart) {

        if (byStart === true) {
            depts.sort(function (dept1, dept2) {
                if (dept1.start < dept2.start) {
                    return -1;
                } else if (dept1.start > dept2.start) {
                    return 1;
                } else {
                    return 0;
                }
            });
        } else {
            depts.sort(function (dept1, dept2) {
                if (dept1.end < dept2.end) {
                    return -1;
                } else if (dept1.end > dept2.end) {
                    return 1;
                } else {
                    return 0;
                }
            });
        }

    }

    function buildMovieMiniTimeline(movieData) {

        if (movieData.phases != null) {

            var phaseSlugs = [];
            var timelineEnd = new Date('1/1/1976');
                        
            //
            //
            // determine start date
            //
            //

            // sort all departments by start date
            sortMovieDepartments(movieData, true);
                                    
            var timelineStart = null;
            if (movieData.phases.development.departments.length > 0) {
                
                timelineStart = movieData.phases.development.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.development.departments, false);

                var phaseEnd = movieData.phases.development.departments[movieData.phases.development.departments.length - 1].end;

                var slug = {
                    phase: 'Development',
                    start: timelineStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

                timelineEnd = (phaseEnd > timelineEnd ? phaseEnd : timelineEnd);

            }
            if (movieData.phases.preProduction.departments.length > 0) {
                
                if (timelineStart == null) {
                    timelineStart = movieData.phases.preProduction.departments[0].start;
                }

                var phaseStart = movieData.phases.preProduction.departments[0].start;
                
                // sort departments by end date
                sortDepartments(movieData.phases.preProduction.departments, false);

                var phaseEnd = movieData.phases.preProduction.departments[movieData.phases.preProduction.departments.length - 1].end;

                var slug = {
                    phase: 'Pre-Production',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

                timelineEnd = (phaseEnd > timelineEnd ? phaseEnd : timelineEnd);

            }
            if (movieData.phases.production.departments.length > 0) {
                
                if (timelineStart == null) {
                    timelineStart = movieData.phases.production.departments[0].start;
                }

                var phaseStart = movieData.phases.production.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.production.departments, false);

                var phaseEnd = movieData.phases.production.departments[movieData.phases.production.departments.length - 1].end;
                               
                var slug = {
                    phase: 'Production',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

                timelineEnd = (phaseEnd > timelineEnd ? phaseEnd : timelineEnd);

            }
            if (movieData.phases.postProduction.departments.length > 0) {
                
                if (timelineStart == null) {
                    timelineStart = movieData.phases.postProduction.departments[0].start;
                }

                var phaseStart = movieData.phases.postProduction.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.postProduction.departments, false);

                var phaseEnd = movieData.phases.postProduction.departments[movieData.phases.postProduction.departments.length - 1].end;

                var slug = {
                    phase: 'Post-Production',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

                timelineEnd = (phaseEnd > timelineEnd ? phaseEnd : timelineEnd);

            }
            if (movieData.phases.distribution.departments.length > 0) {

                if (timelineStart == null) {
                    // don't even bother
                    return;
                }

                var phaseStart = movieData.phases.distribution.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.distribution.departments, false);

                var phaseEnd = movieData.phases.distribution.departments[movieData.phases.distribution.departments.length - 1].end;

                var slug = {
                    phase: 'Distribution',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

                timelineEnd = (phaseEnd > timelineEnd ? phaseEnd : timelineEnd);

            }

            var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

            //
            // we now have all the data required to build the timeline...so do it!
            //

            var timelineContainer = document.createElement('div');
            timelineContainer.id = 'mini-timeline-container';                        

            var labelStart = document.createElement('div');
            labelStart.id = 'mini-timeline-label-start';
            labelStart.innerHTML = monthNames[timelineStart.getMonth()] + '<br />' + timelineStart.getFullYear();
            timelineContainer.appendChild(labelStart);

            var labelEnd = document.createElement('div');
            labelEnd.id = 'mini-timeline-label-end';
            labelEnd.innerHTML = monthNames[timelineEnd.getMonth()] + '<br />' + timelineEnd.getFullYear();
            timelineContainer.appendChild(labelEnd);

            var markerStart = document.createElement('div');
            markerStart.id = 'mini-timeline-marker-start';
            timelineContainer.appendChild(markerStart);

            var markerMiddle = document.createElement('div');
            markerMiddle.id = 'mini-timeline-marker-middle';
            timelineContainer.appendChild(markerMiddle);

            var markerEnd = document.createElement('div');
            markerEnd.id = 'mini-timeline-marker-end';
            timelineContainer.appendChild(markerEnd);

            var movieTicks = (timelineEnd.getTime() - timelineStart.getTime());
            var phaseSlugLength = phaseSlugs.length;
            var middleMarkerWidth = 356;
            var nextLeft = 22;
            var widthTally = 0;

            for (var index = 0; index < phaseSlugLength; index++) {

                var phaseSlug = phaseSlugs[index];

                //
                // calculate phase width based on its scale
                // in relation to the entire movie start/end dates
                //
                var phaseTicks = (phaseSlug.end.getTime() - phaseSlug.start.getTime());

                var width;

                if (index < (phaseSlugLength - 1)) {
                    width = Math.round(middleMarkerWidth * (phaseTicks / movieTicks));
                    widthTally += width;
                } else {
                    width = middleMarkerWidth - widthTally;
                }                 
                
                var slug = document.createElement('div');
                slug.className = 'mini-timeline-phase timeline-' + phaseSlug.phase.toLowerCase();
                slug.title = phaseSlug.phase;
                slug.style.left = nextLeft + 'px';
                slug.style.width = width + 'px';
                
                timelineContainer.appendChild(slug);
                
                nextLeft += width;

            }
            
            var todayMarker = document.createElement('div');
            todayMarker.id = 'mini-timeline-marker-today';
            var todayTicks = (new Date().getTime() - timelineStart.getTime());
            var todayLeft = Math.round(middleMarkerWidth * (todayTicks / movieTicks));
            todayMarker.style.left = todayLeft + 'px';

            timelineContainer.appendChild(todayMarker);

            var todayLabel = document.createElement('div');
            todayLabel.id = 'mini-timeline-label-today';
            todayLabel.textContent = 'Today';
            todayLabel.style.left = (todayLeft - 13) + 'px';

            timelineContainer.appendChild(todayLabel);

            return timelineContainer;

        } else {
            return null;
        }

    }

    function renderDetailsContext(view) {

        var $container = $('#details-container');
        var $icon = $('#details-expand-collapse');
        var $context = $('#details-context-wrapper');

        var isExpanded = true;

        if (typeof (Storage) !== "undefined") {
            isExpanded =(localStorage.getItem('detailsIsExpanded-' + view) == 'true');
        }

        if (isExpanded) {
            $container.css('height', 'auto');
            $icon.css('background-image', 'url("../img/icons/collapse.png")');
            $context.show();
        } else {
            $container.css('height', $('#details-caption').height() + $('.details-item-phase').height() + 'px');
            $icon.css('background-image', 'url("../img/icons/expand.png")');
            $context.hide();
        }
    }

    function showReleaseCountdown(releaseDate, releaseCountry) {

        $('#countdown-clock .label').text(releaseCountry.toUpperCase() + ' THEATRICAL RELEASE IN');
        
        $('#countdown-clock').css('opacity', 1);

        $('#countdown-clock').fadeIn('fast');

        $('#countdown-clock').countdown(releaseDate, function (event) {
            $this = $(this);
            switch (event.type) {
                case "days":
                    $this.find('.daysLeft').html(event.value + ' <span class="unit">DAYS</span>');
                    break;
                case "finished":
                    $this.fadeTo('slow', .5);
                    break;
            }
        });

    }

    function hideReleaseCountdown() {

        $('#countdown-clock').fadeOut('fast');

    }

    function getTimelineDataForCatalog(studioData) {

        var timelineData = [];

        var catalogLength = studioData.catalog.length;

        for (var movieIndex = 0; movieIndex < catalogLength; movieIndex++) {

            var movie = studioData.catalog[movieIndex];

            var item = {};
            item['content'] = movie.name;
            item['tooltip'] = movie.name;
            item['terminator'] = getTerminatorUri(movie.status);
            item['className'] = 'timeline-item timeline-' + movie.currentPhase.toLowerCase();

            if (movie.phases) {

                var phaseData = getPhases(movie);
                item['start'] = phaseData[0].start; // first start date in first phase

            } else {

                var start = new Date(movie.releaseDate).setDate(movie.releaseDate.getDate() - 540);
                item['start'] = new Date(start); // releaseDate minus 540 days

            }

            var end = new Date(movie.releaseDate).setDate(movie.releaseDate.getDate() + 90);
            item['end'] = new Date(end); // releaseDate plus 90 days

            timelineData.push(item);
        }

        return timelineData;

    }

    function getTimelineDataForMovie(movie) {

        var timelineData = [];

        //
        // create milestone item for release date
        //
        var releaseText = movie.releaseCountry + ' Theatrical Release';
        var releaseMilestone = {};
        releaseMilestone['content'] = releaseText;
        releaseMilestone['tooltip'] = releaseText;
        releaseMilestone['terminator'] = null;
        releaseMilestone['className'] = 'future';
        releaseMilestone['start'] = movie.releaseDate;
        timelineData.push(releaseMilestone);

        if (movie.phases) {

            var addItem = function (dept, phase) {

                var item = {};
                item['content'] = dept.name;
                item['tooltip'] = dept.name;
                item['terminator'] = getTerminatorUri(dept.status);
                item['className'] = 'timeline-item timeline-' + phase.toLowerCase();
                item['start'] = dept.start;
                item['end'] = dept.end;

                timelineData.push(item);
            }

            //
            // Development phase departments
            //
            var deptLength = movie.phases.development.departments.length;
            for (var deptIndex = 0; deptIndex < deptLength; deptIndex++) {

                var dept = movie.phases.development.departments[deptIndex];
                addItem(dept, 'development');

            }

            //
            // Pre-Production phase departments
            //
            deptLength = movie.phases.preProduction.departments.length;
            for (var deptIndex = 0; deptIndex < deptLength; deptIndex++) {

                var dept = movie.phases.preProduction.departments[deptIndex];
                addItem(dept, 'pre-production');

            }

            //
            // Production phase departments
            //
            deptLength = movie.phases.production.departments.length;
            for (var deptIndex = 0; deptIndex < deptLength; deptIndex++) {

                var dept = movie.phases.production.departments[deptIndex];
                addItem(dept, 'production');

            }

            //
            // Post-Production phase departments
            //
            deptLength = movie.phases.postProduction.departments.length;
            for (var deptIndex = 0; deptIndex < deptLength; deptIndex++) {

                var dept = movie.phases.postProduction.departments[deptIndex];
                addItem(dept, 'post-production');

            }

            //
            // Distribution phase departments
            //
            deptLength = movie.phases.distribution.departments.length;
            for (var deptIndex = 0; deptIndex < deptLength; deptIndex++) {

                var dept = movie.phases.distribution.departments[deptIndex];
                addItem(dept, 'distribution');

            }

        }

        return timelineData;

    }

    function redrawTimeline() {
        var range = _timeline.getVisibleChartRange();
        _timeline.setVisibleChartRange(range.start, range.end);

        if (_timeline.dom.contentTimelines.clientHeight == 0) {
            setTimeout(redrawTimeline, 100);
        }
    }

    function getPhases(movieData, min, max) {

        if (movieData.phases != null) {

            var phaseSlugs = [];

            //
            //
            // determine start date
            //
            //

            // sort all departments by start date
            sortMovieDepartments(movieData, true);

            var timelineStart = null;
            if (movieData.phases.development.departments.length > 0) {

                timelineStart = movieData.phases.development.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.development.departments, false);

                var phaseEnd = movieData.phases.development.departments[movieData.phases.development.departments.length - 1].end;

                var slug = {
                    phase: 'Development',
                    start: timelineStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

            }
            if (movieData.phases.preProduction.departments.length > 0) {

                if (timelineStart == null) {
                    timelineStart = movieData.phases.preProduction.departments[0].start;
                }

                var phaseStart = movieData.phases.preProduction.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.preProduction.departments, false);

                var phaseEnd = movieData.phases.preProduction.departments[movieData.phases.preProduction.departments.length - 1].end;

                var slug = {
                    phase: 'Pre-Production',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

            }
            if (movieData.phases.production.departments.length > 0) {

                if (timelineStart == null) {
                    timelineStart = movieData.phases.production.departments[0].start;
                }

                var phaseStart = movieData.phases.production.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.production.departments, false);

                var phaseEnd = movieData.phases.production.departments[movieData.phases.production.departments.length - 1].end;

                var slug = {
                    phase: 'Production',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

            }
            if (movieData.phases.postProduction.departments.length > 0) {

                if (timelineStart == null) {
                    timelineStart = movieData.phases.postProduction.departments[0].start;
                }

                var phaseStart = movieData.phases.postProduction.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.postProduction.departments, false);

                var phaseEnd = movieData.phases.postProduction.departments[movieData.phases.postProduction.departments.length - 1].end;

                var slug = {
                    phase: 'Post-Production',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);

            }
            if (movieData.phases.distribution.departments.length > 0) {

                if (timelineStart == null) {
                    // don't even bother
                    return;
                }

                var phaseStart = movieData.phases.distribution.departments[0].start;

                // sort departments by end date
                sortDepartments(movieData.phases.distribution.departments, false);

                var phaseEnd = movieData.phases.distribution.departments[movieData.phases.distribution.departments.length - 1].end;

                var slug = {
                    phase: 'Distribution',
                    start: phaseStart,
                    end: phaseEnd
                };

                phaseSlugs.push(slug);
            }

            //
            // if applicable, adjust first and last phases so 
            // their start/end dates match timeline
            //
            if (min) {
                phaseSlugs[0].start = min;
            }
            if (max) {
                phaseSlugs[phaseSlugs.length - 1].end = max;
            }

            return phaseSlugs;

        } else {
            return null;
        }

    }

    function getTerminatorUri(status) {

        switch (status) {
            case 'pending':
                return '/img/icons/square-blue.png';
            case 'critical':
                return '/img/icons/diamond-red.png';
            case 'warning':
                return '/img/icons/triangle-yellow.png';
            case 'okay':
                return '/img/icons/circle-green.png';
            case 'inactive':
            default:
                return null;
        }

    }

    function showScheduleView(duration) {

        var timelineOptions = {
            height: "100%",
            axisOnTop: true,
            showPhases: false,
            animate: false,
            animateZoom: false,
            selectable: true,
            editable: false,
            moveable: true,
            showMajorMarker: false
        };

        var timelineData;
        var minDate;
        var maxDate;
        var timelineMin;
        var timelineMax;
        var renderTimeline = true;
               

        if (_currentView == CG.Demo1.Views.Catalog) {

            // show catalog schedule
            timelineData = getTimelineDataForCatalog(_studioData);

            if (timelineData.length > 0) {

                setBackNav(CG.Demo1.Views.None, '');

                _timeline = new links.Timeline(document.getElementById('timeline-container'));

                minDate = new Date(timelineData[0].start).setDate(timelineData[0].start.getDate() - 60);
                maxDate = new Date(timelineData[timelineData.length - 1].end).setDate(timelineData[timelineData.length - 1].end.getDate() + 60);

                timelineMin = new Date(minDate);
                timelineMax = new Date(maxDate);

                _hammer.off('tap', '.timeline-event', onTimelineDepartmentClick);
                _hammer.on('tap', '.timeline-event', onTimelineMovieClick);
            } else {

                renderTimeline = false;

            }            
        } else {

            // show movie schedule
            timelineData = getTimelineDataForMovie(_lastMovieTile.movieData);

            //
            // check > 1 because one record will be there
            // for the automatic movie release milestone
            //
            if (timelineData.length > 1) {

                setBackNav(CG.Demo1.Views.CatalogSchedule, 'Pipeline Catalog');

                _timeline = new links.Timeline(document.getElementById('timeline-container'));

                _hammer.off('tap', '.timeline-event', onTimelineMovieClick);
                _hammer.on('tap', '.timeline-event', onTimelineDepartmentClick);

                renderMovieDetails(_lastMovieTile);
                renderDetailsContext(1);

                minDate = new Date(timelineData[1].start).setDate(timelineData[1].start.getDate() - 60); // start at 2nd element to allow for static milestone
                maxDate = new Date(timelineData[timelineData.length - 1].end).setDate(timelineData[timelineData.length - 1].end.getDate() + 60);
                var releasePlus30 = new Date(_lastMovieTile.movieData.releaseDate).setDate(_lastMovieTile.movieData.releaseDate.getDate() + 60);
                maxDate = (maxDate > releasePlus30 ? maxDate : releasePlus30);

                timelineMin = new Date(minDate);
                timelineMax = new Date(maxDate);

                timelineOptions.phases = getPhases(_lastMovieTile.movieData, timelineMin, timelineMax);
                timelineOptions.showPhases = true;

            } else {

                renderTimeline = false;

            }
        }

        if (renderTimeline) {

            timelineOptions.min = timelineMin;
            timelineOptions.max = timelineMax;
            timelineOptions.start = timelineMin;
            timelineOptions.end = timelineMax;

            _timeline.draw(timelineData, timelineOptions);

            redrawTimeline();

        }
    }

    function hideScheduleView() {

        if ($timelineContainer.css('display') != 'none') {

            $timelineContainer.fadeOut('slow');

        }

        if ($viewport.css('display') == 'none') {

            $viewport.fadeIn('slow');

        }

    }

    function hide2D3DView() {

        if ($viewport.css('display') != 'none') {

            $viewport.fadeOut('slow');            

        }

        if ($timelineContainer.css('display') == 'none') {

            $timelineContainer.fadeIn('slow');

        }


    }

    function onTimelineMovieClick(event) {

        event.gesture.preventDefault();

        var movieName = event.gesture.target.textContent;
        var movieTile = getMovieTile(movieName);
        showDepartments(movieTile, true);
        toggleView(CG.Demo1.Toggles.ToggleSchedule, 800);

    }

    function onTimelineDepartmentClick(event) {

        event.gesture.preventDefault();

        var deptName = event.gesture.target.textContent;
        var deptTile = getDepartmentTile(deptName);

        if (deptTile != null) {            
            var toggle = (_wasLastTileView3D == true ? CG.Demo1.Toggles.Toggle3D : CG.Demo1.Toggles.Toggle2D);
            toggleView(toggle, 800);
            setBackNav(CG.Demo1.Views.Departments, 'Departments');
            showAssets(deptTile);
        }

    }

    function getMovieTile(movieName) {

        var movieTile = null;
        var movieLength = _tileObjects.movieObjects.length;

        for (var movieObjectIndex = 0; movieObjectIndex < movieLength; movieObjectIndex++) {

            var movieObject = _tileObjects.movieObjects[movieObjectIndex];
            var tile = movieObject.element;

            if (tile.movieData.name === movieName) {

                //
                // found the right movie
                //

                movieTile = tile;

                break;
            }

        }

        return movieTile;
    }

    function getDepartmentTile(departmentName) {

        var departmentTile = null;
        var tileLength = _currentTileObjects.length;

        for (var tileIndex = 0; tileIndex < tileLength; tileIndex++) {
            var tile = _currentTileObjects[tileIndex].element;

            if (tile.departmentName) {
                if (tile.departmentName == departmentName) {
                    departmentTile = tile;
                    break;
                }
            } else {
                break;
            }
        }

        if (departmentTile == null) {
            //
            // this probably means that the schedule view was
            // toggled from an asset view...so we've got
            // to do this the hard way
            //

            var movieLength = _tileObjects.movieObjects.length;

            for (var movieObjectIndex = 0; movieObjectIndex < movieLength; movieObjectIndex++) {

                var movieObject = _tileObjects.movieObjects[movieObjectIndex];
                var movieTile = movieObject.element;

                if (movieTile.movieData.name === _lastMovieTile.movieData.name) {

                    //
                    // found the right movie, so now find the right department
                    //

                    if (movieObject.departmentObjects && movieObject.departmentObjects.length > 0) {

                        var deptLength = movieObject.departmentObjects.length;

                        for (var deptIndex = 0; deptIndex < deptLength; deptIndex++) {

                            var deptTile = movieObject.departmentObjects[deptIndex].element;

                            if (deptTile.departmentName == departmentName) {
                                departmentTile = deptTile;
                                break;
                            }

                        }
                    }

                    break;

                }

            }

        }

        return departmentTile;

    }
    
    initialize();
    resizeItemViewer();
    animate();


}
